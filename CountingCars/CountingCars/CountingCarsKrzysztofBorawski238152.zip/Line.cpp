#include "Line.h"

Line::Line(Point p1, Point p2)
{
	this->p_1 = p1;
	this->p_2 = p2;
}

