#include<opencv2/opencv.hpp>

using namespace cv;

class Line
{
public:
	Line(Point p1, Point p2);
	Point p_1;
	Point p_2;
};

